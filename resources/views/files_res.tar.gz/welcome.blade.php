
@extends('layouts.app')
@section('title','Homepage')

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/welcome.css') }}">
@endsection

@section('content')

    <!-- support bar area start  -->
    @include('sections.support_bar')
    <!-- support bar area end  -->

    <!-- navbar area start -->
    @include('partials.navbar-home')
    <!-- navbar area end -->

    <!-- header area start  -->
    @include('sections.header')
    <!-- header area end  -->

    <!-- about area start  -->
    @include('sections.about')
    <!-- about area end -->

    <!-- why us area start -->
    @include('sections.whyus')
    <!-- why us area end -->

    <!-- portfolio area start -->
    @include('sections.portfolio')
    <!-- portfolio area end -->

    <!-- our service area start -->
    @include('sections.ourservices')
    <!-- our service area end -->

    <!-- teastimonal area start -->
    @include('sections.testimonials')
    <!-- teastimonal area end -->

@endsection

@section('scripts')
    <script>
        $('.ul-full-width-item').click(function(){
            var id = $(this).attr('id');
            var idNum = id.substr(3,id.length);
            $('.elemento').hide();
            $('#id_portfl_'+idNum).show();
            $('#id_portfl_'+idNum).addClass('animated zoomIn');
    
        });
    </script>
@endsection

