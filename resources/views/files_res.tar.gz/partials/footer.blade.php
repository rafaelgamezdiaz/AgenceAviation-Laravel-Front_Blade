<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="copyright-area">
                    Copyright By - Agence - 2018
                </div>
            </div>
            <!-- //.col-lg-12 -->
        </div>
        <!-- //.row -->
    </div>
    <!-- //.container -->
</footer>